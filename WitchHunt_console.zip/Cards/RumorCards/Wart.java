package WitchHunt.Cards.RumorCards;

import WitchHunt.Players.Player;

public class Wart extends RumorCard {
    private final String name="Wart";

    public Player takeEffectWitch(Player p1,Player accuser){
        System.out.println(p1.getName()+"uses Wart-Witch?");
        return p1;
    }

    public Player takeEffectHunt(Player p1){
        System.out.println(p1.getName()+"uses Wart-hunt");
        return p1.selectPlayer();
    }

    public String getName(){
        return this.name;
    }

}
