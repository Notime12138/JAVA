package WitchHunt.Cards.RumorCards;

import WitchHunt.Players.Player;

public abstract class RumorCard {
    //whether it's usable
    private String name;
    private boolean status;
    private String effectHunt;
    private String effectWitch;

    public abstract Player takeEffectHunt(Player p1);

    public abstract Player takeEffectWitch(Player p1,Player accuser);

    //getter and setter funcitons
    public boolean isRevealed() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getName(){
        return this.name;
    }

    public boolean playableHunt(Player p) {
        return true;
    }

    public boolean playableWitch(Player p) {
        return true;
    }


}
