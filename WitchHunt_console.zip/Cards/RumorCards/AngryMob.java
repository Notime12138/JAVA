package WitchHunt.Cards.RumorCards;

import WitchHunt.Cards.IdentityCards.Identity;
import WitchHunt.Players.Player;

public class AngryMob extends RumorCard {
    private final String name="Angry Mob";



    public Player takeEffectWitch(Player p1,Player accuser){
        System.out.println(p1.getName()+"uses Angry Mob-Witch?");
        return p1;
    }

    public Player takeEffectHunt(Player p1){
        Player nextPlayer = p1.selectPlayer();
        nextPlayer.revealIdentity();
        Identity id = nextPlayer.getIdentity().getIdentity();
        System.out.println(p1.getName()+"uses Angry Mob-hunt");
        System.out.println(p1.getName()+" reveals "+nextPlayer.getName());
        System.out.println(nextPlayer.getName()+" identity is:"+id);
        if (id == Identity.Witch){
            p1.addPoint(2);
            return p1;
        }else {
            p1.addPoint(-2);
            return nextPlayer;
        }
    }

    public String getName(){
        return this.name;
    }

    public boolean playableHunt(Player p1){
        return p1.isIdentityRevealed() && p1.getIdentity().getIdentity() == Identity.Villager;
    }

}
