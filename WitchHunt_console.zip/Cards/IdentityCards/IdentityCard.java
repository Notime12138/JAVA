package WitchHunt.Cards.IdentityCards;

public class IdentityCard {
    Identity identity;

    public IdentityCard(Identity identity) {
        this.identity = identity;
    }

    public Identity getIdentity() {
        return this.identity;
    }

    public void setIdentity(Identity identity) {
        this.identity = identity;
    }

}
