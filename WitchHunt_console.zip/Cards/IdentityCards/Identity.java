package WitchHunt.Cards.IdentityCards;

public enum Identity {
    Witch,
    Villager
}
