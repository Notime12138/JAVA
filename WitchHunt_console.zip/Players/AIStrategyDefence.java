package WitchHunt.Players;

import java.util.ArrayList;
import java.util.Random;

public class AIStrategyDefence implements AIStrategy {

    @Override
    public String nextAction(VirtuelPlayer vp) {
        if (vp.getUsableCardsH().isEmpty()) {
            return "Accuser";
        }
        int choice = new Random().nextInt(7);
        if (choice == 0 || choice == 1) {
            return "Accuser";
        } else {
            return "Reveal";
        }
    }

    @Override
    public Player getPlayerToAccuse(VirtuelPlayer vp) {
        ArrayList<Player> players = vp.getAvailableAccused();
        int choice = new Random().nextInt(players.size());
        return players.get(choice);
    }
}
