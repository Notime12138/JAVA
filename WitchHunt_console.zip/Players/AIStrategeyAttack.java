package WitchHunt.Players;

import java.util.ArrayList;
import java.util.Random;

public class AIStrategeyAttack implements AIStrategy {
    @Override
    public String nextAction(VirtuelPlayer vp) {
        if (vp.getUsableCardsH().isEmpty()) {
            return "Accuser";
        }
        int choice = new Random().nextInt(4);
        if (choice == 0 || choice == 1) {
            return "Reveal";
        } else {
            return "Accuser";
        }
    }

    @Override
    public Player getPlayerToAccuse(VirtuelPlayer vp) {
        ArrayList<Player> players = vp.getAvailableAccused();
        Player toAccuse = players.get(0);
        int nbCard = 5;
        for (Player p : players) {
            if (p.getUsableCardsW().size() < nbCard) {
                nbCard = p.getUsableCardsW().size();
                toAccuse = p;
            }
        }
        return toAccuse;
    }
}
