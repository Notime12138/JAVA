package WitchHunt.Players;

import WitchHunt.Cards.IdentityCards.Identity;
import WitchHunt.Cards.RumorCards.RumorCard;
import WitchHunt.Game;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class HumanPlayer extends Player {

    public HumanPlayer(int nb_card, String name, Game game) {
        super(nb_card, name, game);
    }

    @Override
    public boolean isBot() {
        return false;
    }

    @Override
    public void chooseIdentity() {
        System.out.println(this.getName() + "! Choisissez votre Idenetité :\n" +
                "1 : Witch\n" +
                "2 : Villager");
        Scanner scanner = new Scanner(System.in);
        String choice = scanner.nextLine();
        if (Objects.equals(choice, "1") || Objects.equals(choice, "Witch") || Objects.equals(choice, "witch") || Objects.equals(choice, "w") || Objects.equals(choice, "W")) {
            this.setIdentity(Identity.Witch);
        } else {
            this.setIdentity((Identity.Villager));
        }
    }

    @Override
    public Player defendAccusation(Player accuser) {
        System.out.println(this.getName() + ",Vous pouvez utiliser les cartes suivantes pour la défense ou ouvrir directement la carte d'identité");
        ArrayList<RumorCard> usable = this.getUsableCardsW();
        Player nextPlayer;
        if (usable.isEmpty()) {
            System.out.println("Sorry, you dont have any card");
        }
            for (RumorCard card : usable) {
                System.out.println(usable.indexOf(card) + 1 + " " + card.getName());
            }
            System.out.println("Voulez vous : \n" +
                    "\t1 : Réléver votre identité\n" +
                    "\t2 : Réléver une carte");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();
            if (choice == 1 || usable.isEmpty()) {
                nextPlayer = this.nextPlayerRevealIdentity(accuser);
            } else {
                System.out.println("Now choose your card");
                Scanner scanner1 = new Scanner(System.in);
                int cardIndex = scanner1.nextInt();
                RumorCard card = usable.get(cardIndex - 1);
                nextPlayer = card.takeEffectWitch(this, accuser);
                this.revealCard(card);
            }
            return nextPlayer;
    }

    @Override
    public Player play() {

        Player nextPlayer;
        ArrayList<RumorCard> usable = this.getUsableCardsH();
        if (usable.isEmpty()) {
            System.out.println("Sorry, you dont have any card, you can only hunt");
        }

        System.out.println("Vous voulez: \n" +
                "1 accuser\n" +
                "2 hunt");

        Scanner scanner1 = new Scanner(System.in);
        int choice = scanner1.nextInt();


        System.out.println("You can use these cards");
        for (RumorCard card : usable) {
            System.out.println(usable.indexOf(card) + 1 + " " + card.getName());
        }

        if (choice == 1 || usable.size() == 0) {
            ArrayList<Player> available = this.getAvailableAccused();
            for (Player p : available) {
                System.out.println(available.indexOf(p)+1 + " " + p.getName());
            }
            System.out.println("Entrez l'index du joueur que vous souhaitez accuser");
            Scanner scannerP = new Scanner(System.in);
            int indexP = scannerP.nextInt();

            Player toAccuse = available.get(indexP - 1);
            nextPlayer = this.accuse(toAccuse);
        } else {
            /*
            for (RumorCard card : usable) {
                System.out.println(usable.indexOf(card)+1 + " " + card.getName());
            }
            */
            System.out.println("Entrez l'index de la carte que vous souhaitez utiliser");
            Scanner scannerC = new Scanner(System.in);
            int indexC = scannerC.nextInt();

            RumorCard cardU = usable.get(indexC - 1);
            cardU.setStatus(true);
            nextPlayer = cardU.takeEffectHunt(this);
        }
        return nextPlayer;
    }

    @Override
    public int chooseCase() {
        System.out.println("Vous voulez :\n" +
                "1 reveal identity\n" +
                "2 discard a card\n" +
                "Entre the number(1 / 2)");
        Scanner scanner = new Scanner(System.in);
        return scanner.nextInt();
    }

    @Override
    public Player selectPlayer() {
        ArrayList<Player> available = this.getAvailablePlayers();
        for (Player p : available) {
            if (p.isIdentityRevealed()) {
                System.out.println(available.indexOf(p)+1 + " " + p.getName() + " : " + p.getIdentity().getIdentity());
            } else {
                System.out.println(available.indexOf(p)+1 + " " + p.getName());
            }
        }
        System.out.println("Entre the index,not yourself");
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        return available.get(choice - 1);
    }

}
