package WitchHunt.Players;

public interface AIStrategy {
    Player getPlayerToAccuse(VirtuelPlayer vp);

    String nextAction(VirtuelPlayer vp);

}
