package WitchHunt;

import WitchHunt.Cards.RumorCards.*;
import WitchHunt.Players.HumanPlayer;
import WitchHunt.Players.Player;
import WitchHunt.Players.VirtuelPlayer;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;

public class Game {
    private final int numPlayer;
    private static Game instance = null;
    private final ArrayList<Player> playerList;
    private final ArrayList<RumorCard> cardList;
    private Player nextPlayer;
    private final int cardPerPlayer;

    private Game(int nb_players) {
        this.numPlayer = nb_players;
        this.cardPerPlayer = getCardPerPlayer(nb_players);
        this.playerList = createPlayers(nb_players,this.cardPerPlayer);
        this.nextPlayer = this.playerList.get((int)(1+Math.random()*(nb_players)));
        this.cardList = createCards();
    }

    public static Game getInstance(int nb) {
        if (instance == null) {
            instance = new Game(nb);
        }return instance;
    }

    public int getCardPerPlayer(int nb_player) {
        int nb_card;
        if (nb_player == 6) {
            nb_card = 2;
        } else {
            nb_card = 7 - nb_player;
        }
        return nb_card;
    }

    private @NotNull ArrayList<Player> createPlayers(int nb_players, int nb_card) {
        final ArrayList<Player> newPlayers = new ArrayList<>(nb_players);
        newPlayers.add(new HumanPlayer(nb_card, "Joueur", this));
        for (int i = 0; i < nb_players - 1; i++) {
            newPlayers.add(new VirtuelPlayer(nb_card, "BOT" + i, this));
        }return newPlayers;
    }

    private @NotNull ArrayList<RumorCard> createCards() {
        final ArrayList<RumorCard> cards = new ArrayList<>(13);
        Collections.addAll(cards,
                new AngryMob(),
                new TheInquisition(),
                new PointedHat(),
                new HookedNose(),
                new BroomStick(),
                new Wart(),
                new DuckingStool(),
                new Cauldron(),
                new EvilEye(),
                new Toad(),
                new BlackCat(),
                new PetNewt());
        Collections.shuffle(cards);
        return cards;
    }

    private void donnerCards() {
        System.out.println(this.cardList.size());
        System.out.println(this.playerList.size() + " players are playing");
        for (Player p : this.playerList) {
           for (int i = 0; i < this.cardPerPlayer; ++i) {
                p.getCard(this.cardList.get(0));
                this.cardList.remove(0);
            }
        }
        this.cardList.trimToSize();

//        while (!this.cardList.isEmpty()) {
//                for (int i = 0; i < this.cardPerPlayer; ++i) {
//                    for (Player p : this.playerList) {
//                        p.getCard(this.cardList.remove(this.cardList.size() - 1));
//                    }
//                }
//                this.cardList.trimToSize();
//        }
        if (this.cardList.isEmpty()) {
            System.out.println("No cards remain");
        } else {
            for (RumorCard card : this.cardList) {
                System.out.println("remains these cards" + card.getName());
            }
        }
    }

    public void getDiscardedCard(RumorCard card) {
        this.cardList.add(card);
    }

    public boolean isGameEnded() {
        for (Player p : this.playerList) {
            if (p.getPoint() >= 5) {
                return true;
            }
        }
        return false;
    }

    public Player getHighest() {
        Player playerH = playerList.get(0);
        for (Player p : playerList) {
            if (p.getPoint() > playerH.getPoint()) {
                playerH = p;
            }
        }
        return playerH;
    }

    /*
    public int getNumPlayer() {
        return numPlayer;
    }

    public  void addBot(int nb_bot) {
        numPlayer += nb_bot;
    }

    public  void addBot() {
        numPlayer++;
    }
*/
    public ArrayList<Player> getPlayerList() {
        return this.playerList;
    }

    //Cards discarded
    public ArrayList<RumorCard> getCardList() {
        return this.cardList;
    }

    public void startGame() {
        while (! isGameEnded()) {
            this.donnerCards();
            for (Player p : playerList) {
                //test if all cards have been distributed
                System.out.println("\n" + p.getName() + " has these cards\n");
                for (RumorCard card : p.getCardsList()) {
                    System.out.println(p.getCardsList().indexOf(card)+1 + " " + card.getName());
                }
                //every player choose their identity
                p.chooseIdentity();
            }
            this.startRound();
        }
        System.out.println("Le gagnant est : " + this.getHighest() );
    }

    public void startRound() {
        while (! this.isRoundEnded()) {
            this.startTurn();
        }
        System.out.println("Fin du round");
        System.out.println(this.cardList.size());
        this.endRound();
    }

    public boolean isRoundEnded() {
        int nbRevealed = 0;
        for (Player p : playerList) {
            if (p.isIdentityRevealed()) {
                nbRevealed++;
            }
        }
        return nbRevealed == this.numPlayer - 1;
    }

    public void startTurn() {
        System.out.println("C'est le turn de " + nextPlayer.getName());
        ArrayList<RumorCard> usable = nextPlayer.getUsableCards();
        //check the cards at the beginning of their turn
        for (RumorCard card : usable) {
            System.out.println(usable.indexOf(card)+1 + " " + card.getName());
        }
        nextPlayer = nextPlayer.play();
    }

    public void endRound() {
        for (Player p : playerList) {
            p.discardAllCards();
            p.setStatusIdentity(false);
            System.out.println(p.getName() + "'s score : " + p.getPoint());
        }
    }

}
