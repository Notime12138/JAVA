package WitchHunt;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Importer le nombre de joueurs (3 - 6) : ");
        Scanner scanner = new Scanner(System.in);
        int nb = scanner.nextInt();
        if (nb >= 3 && nb <= 6){
            Game game = Game.getInstance(nb);
            game.startGame();
        }else {
            System.out.println("Vous devez commencer une partie avec 3 à 6 joueurs");
        }
    }
}
